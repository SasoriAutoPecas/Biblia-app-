import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

// Interface para os livros
interface Book {
  title: string;
  description: string;
  image: string;
  detailedDescription: string;
  detailedImage: string;
}

@Component({
  selector: 'app-livros',
  templateUrl: './livros.page.html',
  styleUrls: ['./livros.page.scss'],
})
export class LivrosPage {
  // Categorias do Antigo Testamento
  oldTestamentCategories: { name: string; books: Book[] }[] = [
    {
      name: 'Pentateuco',
      books: [
        { title: 'Gênesis', description: 'O início da criação...', image: 'assets/book-cover.jpg', detailedDescription: `O livro de Gênesis é o primeiro da Bíblia e estabelece as bases para toda a narrativa da redenção. Ele revela a criação do universo, o propósito de Deus para a humanidade e o início do relacionamento entre Deus e o homem. Gênesis significa "origens" e narra como Deus criou todas as coisas, desde a luz até a vida, culminando na criação do homem e da mulher à Sua imagem. A criação do homem destaca o valor que Deus atribui à humanidade. No entanto, em Gênesis 3, a desobediência de Adão e Eva introduz o pecado no mundo, separando a humanidade de Deus. Mesmo nesse momento trágico, Deus oferece esperança ao prometer um Redentor, estabelecendo o início do Seu plano redentor. O livro também narra a história de figuras importantes como Noé, Abraão, Isaque, Jacó e José. Cada um deles desempenha um papel crucial na história da salvação. A aliança de Deus com Abraão é particularmente significativa, pois Deus promete que através de sua descendência todas as nações da terra seriam abençoadas. Gênesis nos ensina sobre a fidelidade de Deus, mesmo quando a humanidade falha. Ele é um Deus que busca restaurar o que foi perdido. O que podemos aprender com Gênesis é que, independentemente de nossas circunstâncias ou falhas, Deus está sempre pronto para nos oferecer graça e redenção. Ele nos criou com propósito e valor, e em Cristo encontramos a plenitude desse propósito. Vamos viver de forma a refletir a glória de Deus, lembrando que nossa história começa com Ele.`
          , detailedImage: 'assets/detailed-genesis.png' },
        { title: 'Êxodo', description: 'A libertação dos israelitas...', image: 'assets/book-cover1.jpg', detailedDescription: `O livro de Êxodo é a história de libertação e redenção do povo de Deus. Ele nos leva do cativeiro dos israelitas no Egito à sua libertação milagrosa sob a liderança de Moisés. Êxodo não é apenas uma narrativa histórica; é uma poderosa alegoria da redenção que Deus oferece a todos os que estão cativos pelo pecado. Logo no início do livro, vemos o povo de Israel sofrendo sob o jugo da escravidão egípcia. Mas Deus ouve o clamor de Seu povo e chama Moisés para ser o libertador. Isso nos lembra que Deus sempre vê o sofrimento de Seu povo e nunca permanece indiferente. Através de milagres impressionantes, como as Dez Pragas e a divisão do Mar Vermelho, Deus demonstra Seu poder sobre as forças da natureza e os deuses do Egito. Cada milagre é uma declaração de que Ele é o verdadeiro Deus, soberano sobre tudo. Ao guiar o povo através do deserto, Deus também revela Sua presença constante, simbolizada pela nuvem de dia e a coluna de fogo à noite. Ele promete estar com eles, e isso é um lembrete para nós de que nunca estamos sozinhos em nossas jornadas. A entrega da Lei no Monte Sinai marca um ponto crucial no Êxodo. Deus estabelece um pacto com Seu povo, dando-lhes diretrizes para viver em santidade e comunhão com Ele. Os Dez Mandamentos são princípios fundamentais que ainda nos guiam hoje. A Lei não é uma carga, mas um presente, pois nos ensina a viver em harmonia com Deus e com os outros. O que está te prendendo hoje? Assim como Deus libertou os israelitas da escravidão, Ele também pode te libertar de qualquer cativeiro que você esteja enfrentando. Confie em Sua fidelidade e poder para te guiar na jornada da vida.`
          , detailedImage: 'assets/detailed-exodus.png' },
        { title: 'Levítico', description: 'Leis e regulamentos...', image: 'assets/book-cover2.jpg', detailedDescription: `O livro de Levítico é um manual de santidade e adoração, que estabelece as normas e os princípios que Deus deu ao povo de Israel para que eles pudessem viver em relação correta com Ele. Após a libertação do Egito e a entrega da Lei no Monte Sinai, Levítico fornece orientações detalhadas sobre como os israelitas deveriam adorar a Deus, manter a santidade e viver em comunidade. Este livro enfatiza a importância da santidade, repetindo a exortação de que o povo deve ser santo, pois Deus é santo. Os rituais de sacrifício descritos em Levítico, como as ofertas de holocaustos, ofertas pacíficas e ofertas pelo pecado, são significativos porque mostram que o pecado tem consequências e que a expiação é necessária. Esses sacrifícios apontam para a necessidade de um sacrifício perfeito, que se cumpre em Cristo. Levítico também contém leis sobre pureza ritual, dieta e ética social, mostrando que cada aspecto da vida do povo de Deus deve refletir Sua santidade. O livro aborda a importância do Dia da Expiação, um dia especial em que o sacerdote oferecia sacrifícios pelos pecados do povo, simbolizando a purificação e a reconciliação com Deus. O propósito de Levítico é nos ensinar que a comunhão com Deus é uma coisa séria e que devemos nos aproximar dEle com reverência. O que podemos aprender com Levítico é que Deus ainda espera santidade de Seu povo hoje. Assim como os israelitas eram chamados a viver de acordo com as leis de Deus, nós também somos chamados a viver uma vida que glorifica a Ele em tudo o que fazemos. Vamos nos esforçar para ser um povo separado, dedicado ao Senhor, refletindo Sua luz em um mundo que precisa de esperança.`
          , detailedImage: 'assets/detailed-leviticus.png' },
        { title: 'Números', description: 'O censo dos israelitas...', image: 'assets/book-cover3.jpg', detailedDescription: `O livro de Números é um relato poderoso da jornada do povo de Israel pelo deserto em direção à Terra Prometida. O título "Números" refere-se aos censos realizados, que contabilizam os israelitas, mas também nos ensina sobre a importância da preparação e da organização que Deus exige de Seu povo. Números começa com a contagem dos guerreiros, enfatizando que cada pessoa conta no plano de Deus. Ao longo da jornada, encontramos desafios significativos, incluindo murmurações, desobediências e crises de fé. O povo frequentemente questiona a liderança de Moisés e a providência de Deus, demonstrando a luta humana contra a dúvida e a desconfiança. Contudo, mesmo em meio à infidelidade do povo, a fidelidade de Deus brilha intensamente. Ele continua a guiar, prover e oferecer novas oportunidades. A errância no deserto, que durou 40 anos, não foi apenas um castigo, mas uma preparação. Deus estava moldando o caráter do Seu povo, ensinando-os a confiar Nele e a depender de Sua graça. Em Números 14:8-9, Moisés intercede pelo povo, lembrando-os da bondade de Deus. Isso nos mostra a importância da intercessão e da liderança que aponta o povo de volta ao Senhor. O livro também destaca os desafios da liderança, exemplificados por Moisés e Aarão, que enfrentaram a resistência do povo, mas permaneceram firmes na missão dada por Deus. O que podemos aprender com Números é que, assim como os israelitas, também enfrentamos desafios em nossas vidas. Às vezes, podemos sentir que estamos vagando em desertos de incerteza. Mas Deus nos chama a confiar Nele, a permanecer firmes em Sua promessa e a seguir em frente, mesmo quando o caminho parece difícil. Que possamos aprender a perseverar em nossa jornada, lembrando que Deus está sempre conosco, guiando-nos em cada passo. Ele nunca nos abandona, e Sua graça é suficiente para todas as nossas necessidades.`
          , detailedImage: 'assets/detailed-numbers.png' },
        { title: 'Deuteronômio', description: 'Revisão das leis...', image: 'assets/book-cover4.jpg', detailedDescription: `O livro de Deuteronômio é um poderoso chamado à obediência e um lembrete da fidelidade de Deus ao Seu povo. Escrito como um discurso de Moisés antes da entrada dos israelitas na Terra Prometida, Deuteronômio nos leva a refletir sobre a importância de lembrar quem somos e quem Deus é. O nome "Deuteronômio" significa "segunda lei", pois é uma reiteração das leis dadas anteriormente, enfatizando que a obediência a Deus é fundamental para a vida e a prosperidade. Moisés exorta o povo a amar a Deus de todo o coração, alma e força, lembrando-os de que o Senhor é um Deus ciumento que exige lealdade total. Em Deuteronômio 6:4-5, encontramos o grande mandamento: "Ouça, ó Israel: O Senhor, nosso Deus, é o único Senhor. Ame o Senhor, seu Deus, de todo o seu coração, de toda a sua alma e de todas as suas forças." Isso nos chama a um amor ativo e deliberado por Deus, um amor que se expressa em ações, obediência e devoção. O livro também destaca as consequências da desobediência, advertindo que afastar-se do caminho de Deus traz destruição e tristeza. Mas, mesmo ao lembrar as falhas do passado, Moisés fala sobre a misericórdia e a graça de Deus, que sempre estão disponíveis para aqueles que se arrependem e voltam para Ele. Em Deuteronômio 30:19-20, somos chamados a escolher entre a vida e a morte, a bênção e a maldição, e a escolha de amar e obedecer a Deus é um convite à vida abundante. O que podemos aprender com Deuteronômio é que a nossa relação com Deus deve ser vivida com intensidade e autenticidade. Ele não deseja um amor superficial, mas um amor profundo que transforma nossas vidas. Hoje, Deus nos convida a renovar nosso compromisso com Ele. Que possamos nos lembrar de Sua fidelidade, escolher a vida e viver em obediência, pois somente assim experimentaremos a verdadeira abundância que Ele promete.`
          , detailedImage: 'assets/detailed-deuteronomy.png' },
      ]
    },
    {
      name: 'Livros Históricos',
      books: [
        { title: 'Josué', description: 'Conquista da Terra Prometida...', image: 'assets/book-cover5.jpg', detailedDescription: `O livro de Josué é um testemunho da fidelidade de Deus em cumprir Suas promessas. Ele marca a transição do povo de Israel da peregrinação no deserto para a conquista e possessão da Terra Prometida. Através da liderança corajosa de Josué, Deus demonstra que é fiel à Sua palavra e que a obediência a Ele é a chave para a vitória. Desde o início, quando o povo cruza o Rio Jordão em um milagre impressionante, fica claro que Deus está com eles. Em Josué 1:9, Deus ordena a Josué: "Não te mandei eu? Sê forte e corajoso; não temas nem te espantes, porque o Senhor, teu Deus, é contigo por onde quer que andares." Essa exortação não é apenas para Josué, mas para todos nós! Assim como Deus estava com Josué, Ele está conosco em cada desafio que enfrentamos. O livro também nos ensina sobre a importância da fé e da coragem. Os israelitas enfrentaram enormes desafios, incluindo as muralhas de Jericó. Contudo, quando obedeceram a Deus e confiaram em Sua instrução, as muralhas caíram! Isso nos lembra que as barreiras em nossas vidas podem ser superadas pela fé e pela obediência. A conquista da Terra Prometida não foi apenas uma questão de possessão física, mas também um chamado para que o povo vivesse de acordo com os princípios de Deus. Josué constantemente lembra o povo de que devem permanecer fiéis ao Senhor e não se afastar dos Seus mandamentos. O que podemos aprender com o livro de Josué é que Deus nos chama a conquistar as promessas que Ele nos deu. A vida cristã é uma jornada de fé, e, assim como Josué, somos desafiados a sermos fortes e corajosos. Que possamos olhar para as "muralhas" em nossas vidas e, com fé em Deus, marchar em direção à vitória, lembrando que Ele é fiel para cumprir Suas promessas e nos guiar em cada passo do caminho.`
          , detailedImage: 'assets/detailed-joshua.png' },
        { title: 'Juízes', description: 'Ciclo de desobediência...', image: 'assets/book-cover.jpg', detailedDescription: `O livro de Juízes é um relato profundo das lutas e triunfos do povo de Israel em um período de transição e instabilidade. Após a morte de Josué, Israel entra em uma fase de ciclos repetidos de desobediência, opressão e libertação. Este livro revela a natureza do coração humano e a necessidade constante da intervenção divina. Em Juízes 2:16-19, vemos que, quando o povo se afasta de Deus e se inclina a adorar ídolos, a consequência é a opressão de inimigos. Mas Deus, em Sua infinita misericórdia, levanta juízes, líderes ungidos, para libertar o povo. Esses juízes não são apenas guerreiros; eles são também instrumentos de Deus, chamados a restaurar a justiça e guiar o povo de volta ao Senhor. A história de Débora, uma mulher forte e sábia, e de Gideão, que, apesar de suas inseguranças, confia em Deus e derrota um exército muito maior, nos ensina que Deus pode usar qualquer um, independentemente de sua aparência ou circunstâncias, para cumprir Seus propósitos. O livro de Juízes também é um poderoso lembrete da necessidade de permanecer fiel a Deus em meio à tentação e à adversidade. Juízes 21:25 resume a situação, dizendo que "naqueles dias, não havia rei em Israel; cada um fazia o que parecia reto aos seus olhos". Essa declaração ecoa em nossos dias, onde a falta de liderança e a desobediência a Deus levam a confusão e caos. O que podemos aprender com o livro de Juízes é que a fidelidade a Deus é crucial para a nossa prosperidade e segurança. Hoje, somos chamados a reconhecer a soberania de Deus em nossas vidas, a buscar Sua direção e a resistir às tentações que nos afastam de Sua vontade. Que possamos aprender com os erros do passado e, assim como os juízes, levantar-nos como instrumentos de Deus em um mundo que precisa desesperadamente de Sua verdade e luz. Que, em tudo o que fazemos, possamos honrar a Deus e viver de acordo com Sua Palavra, lembrando que a verdadeira liberdade e justiça só podem ser encontradas Nele.`
, detailedImage: 'assets/detailed-judges.png' },
        { title: 'Rute', description: 'História de lealdade...', image: 'assets/book-cover1.jpg', detailedDescription: `O livro de Rute é uma história de amor, lealdade e redenção que se destaca na narrativa bíblica como um testemunho do plano soberano de Deus. Em um tempo de crise e desespero, Rute, uma moabita, demonstra uma fé inabalável e um compromisso incondicional com sua sogra Noemi. Sua declaração em Rute 1:16-17, "Onde quer que você for, irei; onde quer que você ficar, ficarei; o seu povo será o meu povo, e o seu Deus será o meu Deus", ressoa com profundidade, mostrando que a verdadeira lealdade vai além de laços de sangue e se fundamenta em um relacionamento sincero com Deus. O livro não apenas narra a história de Rute, mas também revela como Deus pode trabalhar nas situações mais difíceis para trazer cura e restauração. Através de Rute, vemos a beleza da redenção, pois ela se torna parte da linhagem de Davi e, consequentemente, de Jesus Cristo. O papel de Boaz, como o "redentor" que assume a responsabilidade pela família de Noemi, simboliza o amor sacrificial e a graça que Deus oferece a todos nós. Boaz não apenas redime Rute, mas também a acolhe com dignidade e respeito. Isso nos ensina sobre o valor que Deus atribui a cada um de nós e nos chama a tratar os outros com compaixão e justiça. O que podemos aprender com o livro de Rute é que Deus está sempre operando em nossas vidas, mesmo em meio às dificuldades. Ele usa pessoas comuns para realizar Seus propósitos extraordinários. Em tempos de dor e perda, assim como Rute e Noemi enfrentaram, podemos confiar que Deus está trabalhando para o nosso bem. Que possamos, como Rute, ter coragem de seguir o caminho da fé e lealdade, sabendo que Deus está conosco em cada passo da jornada. Ao fazermos isso, nos tornamos testemunhas da Sua graça e amor em um mundo que desesperadamente precisa Dele.`
          , detailedImage: 'assets/detailed-ruth.png' },
        { title: '1 Samuel', description: 'História de Samuel e Saul...', image: 'assets/book-cover2.jpg', detailedDescription: 'Transição para o reinado...', detailedImage: 'assets/detailed-1samuel.png' },
        { title: '2 Samuel', description: 'O reinado de Davi...', image: 'assets/book-cover3.jpg', detailedDescription: 'Conquistas e desafios...', detailedImage: 'assets/detailed-2samuel.png' },
        { title: '1 Reis', description: 'História dos reis de Israel...', image: 'assets/book-cover4.jpg', detailedDescription: 'História de Salomão...', detailedImage: 'assets/detailed-1kings.png' },
        { title: '2 Reis', description: 'Continuação dos reinados...', image: 'assets/book-cover5.jpg', detailedDescription: 'Histórias da queda de Israel...', detailedImage: 'assets/detailed-2kings.png' },
        { title: '1 Crônicas', description: 'Genealogias e reinado de Davi...', image: 'assets/book-cover.jpg', detailedDescription: 'Histórias de Davi...', detailedImage: 'assets/detailed-1chronicles.png' },
        { title: '2 Crônicas', description: 'História do templo e dos reis...', image: 'assets/book-cover1.jpg', detailedDescription: 'Histórias de Salomão e outros reis...', detailedImage: 'assets/detailed-2chronicles.jpg' },
        { title: 'Esdras', description: 'O retorno do exílio babilônico...', image: 'assets/book-cover2.jpg', detailedDescription: 'Reconstrução do templo...', detailedImage: 'assets/detailed-ezra.jpg' },
        { title: 'Neemias', description: 'Reconstrução de Jerusalém...', image: 'assets/book-cover3.jpg', detailedDescription: 'Reformas em Israel...', detailedImage: 'assets/detailed-nehemiah.jpg' },
        { title: 'Ester', description: 'Salvação dos judeus na Pérsia...', image: 'assets/book-cover4.jpg', detailedDescription: 'História de Ester...', detailedImage: 'assets/detailed-esther.jpg' },
      ]
    },
    {
      name: 'Livros Poéticos',
      books: [
        { title: 'Jó', description: 'A história do sofrimento...', image: 'assets/book-cover5.jpg', detailedDescription: 'Provações e fé...', detailedImage: 'assets/detailed-job.jpg' },
        { title: 'Salmos', description: 'Cânticos e orações...', image: 'assets/book-cover.jpg', detailedDescription: 'Poesias e louvores...', detailedImage: 'assets/detailed-psalms.jpg' },
        { title: 'Provérbios', description: 'Sabedoria prática...', image: 'assets/book-cover1.jpg', detailedDescription: 'Conselhos práticos...', detailedImage: 'assets/detailed-proverbs.jpg' },
        { title: 'Eclesiastes', description: 'A busca pelo significado da vida...', image: 'assets/book-cover2.jpg', detailedDescription: 'Reflexões sobre a vida...', detailedImage: 'assets/detailed-ecclesiastes.jpg' },
        { title: 'Cânticos dos Cânticos', description: 'Uma celebração do amor...', image: 'assets/book-cover3.jpg', detailedDescription: 'Poema de amor...', detailedImage: 'assets/detailed-songofsolomon.jpg' },
      ]
    },
    {
      name: 'Profetas Maiores',
      books: [
        { title: 'Isaías', description: 'Profecias sobre o Messias...', image: 'assets/book-cover4.jpg', detailedDescription: 'A vinda do Salvador...', detailedImage: 'assets/detailed-isaiah.jpg' },
        { title: 'Jeremias', description: 'Avisos de destruição...', image: 'assets/book-cover5.jpg', detailedDescription: 'Profecias sobre o exílio...', detailedImage: 'assets/detailed-jeremiah.jpg' },
        { title: 'Lamentações', description: 'Lamento pela destruição de Jerusalém...', image: 'assets/book-cover.jpg', detailedDescription: 'Poemas de tristeza...', detailedImage: 'assets/detailed-lamentations.jpg' },
        { title: 'Ezequiel', description: 'Profecias sobre restauração...', image: 'assets/book-cover1.jpg', detailedDescription: 'Visões e mensagens de esperança...', detailedImage: 'assets/detailed-ezekiel.jpg' },
        { title: 'Daniel', description: 'Histórias e visões apocalípticas...', image: 'assets/book-cover2.jpg', detailedDescription: 'Histórias de fé e visões futuras...', detailedImage: 'assets/detailed-daniel.jpg' },
      ]
    },
    {
      name: 'Profetas Menores',
      books: [
        { title: 'Oséias', description: 'O amor de Deus por um povo infiel...', image: 'assets/book-cover3.jpg', detailedDescription: 'A metáfora do casamento...', detailedImage: 'assets/detailed-hosea.jpg' },
        { title: 'Joel', description: 'Profecias de arrependimento...', image: 'assets/book-cover4.jpg', detailedDescription: 'Visões do Dia do Senhor...', detailedImage: 'assets/detailed-joel.jpg' },
        { title: 'Amós', description: 'Justiça para os oprimidos...', image: 'assets/book-cover5.jpg', detailedDescription: 'Avisos de julgamento...', detailedImage: 'assets/detailed-amos.jpg' },
        { title: 'Obadias', description: 'Profecia contra Edom...', image: 'assets/book-cover.jpg', detailedDescription: 'Julgamento de nações...', detailedImage: 'assets/detailed-obadiah.jpg' },
        { title: 'Jonas', description: 'A história de Jonas e Nínive...', image: 'assets/book-cover1.jpg', detailedDescription: 'Arrependimento dos ninivitas...', detailedImage: 'assets/detailed-jonah.jpg' },
        { title: 'Miqueias', description: 'A justiça e a misericórdia de Deus...', image: 'assets/book-cover2.jpg', detailedDescription: 'Avisos e promessas...', detailedImage: 'assets/detailed-micah.jpg' },
        { title: 'Naum', description: 'Profecia contra Nínive...', image: 'assets/book-cover3.jpg', detailedDescription: 'Julgamento contra os inimigos...', detailedImage: 'assets/detailed-nahum.jpg' },
        { title: 'Habacuque', description: 'Diálogo sobre a justiça divina...', image: 'assets/book-cover4.jpg', detailedDescription: 'Lutas com a compreensão de Deus...', detailedImage: 'assets/detailed-habakkuk.jpg' },
        { title: 'Sofonias', description: 'Avisos de julgamento e restauração...', image: 'assets/book-cover5.jpg', detailedDescription: 'Profecias sobre o Dia do Senhor...', detailedImage: 'assets/detailed-zephaniah.jpg' },
        { title: 'Ageu', description: 'Exortação à reconstrução do templo...', image: 'assets/book-cover.jpg', detailedDescription: 'Reforma espiritual...', detailedImage: 'assets/detailed-haggai.jpg' },
        { title: 'Zacarias', description: 'Visões de encorajamento...', image: 'assets/book-cover1.jpg', detailedDescription: 'Profecias messiânicas...', detailedImage: 'assets/detailed-zechariah.jpg' },
        { title: 'Malaquias', description: 'Última profecia do Antigo Testamento...', image: 'assets/book-cover2.jpg', detailedDescription: 'Mensagens sobre a vinda do Messias...', detailedImage: 'assets/detailed-malachi.jpg' },
      ]
    },
  ];

  // Categorias do Novo Testamento
  newTestamentCategories: { name: string; books: Book[] }[] = [
    {
      name: 'Evangelhos',
      books: [
        { title: 'Mateus', description: 'Jesus como o Messias prometido...', image: 'assets/book-cover3.jpg', detailedDescription: 'Narrativa do nascimento e vida de Jesus...', detailedImage: 'assets/detailed-matthew.jpg' },
        { title: 'Marcos', description: 'O ministério de Jesus em ação...', image: 'assets/book-cover4.jpg', detailedDescription: 'Histórias de milagres e o sacrifício de Jesus...', detailedImage: 'assets/detailed-mark.jpg' },
        { title: 'Lucas', description: 'História de Jesus com um enfoque na compaixão...', image: 'assets/book-cover5.jpg', detailedDescription: 'Relatos detalhados da vida de Jesus...', detailedImage: 'assets/detailed-luke.jpg' },
        { title: 'João', description: 'A divindade de Jesus...', image: 'assets/book-cover.jpg', detailedDescription: 'Explora profundamente a natureza divina de Jesus...', detailedImage: 'assets/detailed-john.jpg' },
      ]
    },
    {
      name: 'Histórico',
      books: [
        { title: 'Atos dos Apóstolos', description: 'História da igreja primitiva...', image: 'assets/book-cover1.jpg', detailedDescription: 'A formação da igreja após a ascensão de Cristo...', detailedImage: 'assets/detailed-acts.jpg' },
      ]
    },
    {
      name: 'Cartas Paulinas',
      books: [
        { title: 'Romanos', description: 'Justificação pela fé...', image: 'assets/book-cover2.jpg', detailedDescription: 'Paulo explica a justiça pela fé em Cristo...', detailedImage: 'assets/detailed-romans.jpg' },
        { title: '1 Coríntios', description: 'Paulo exorta a igreja...', image: 'assets/book-cover3.jpg', detailedDescription: 'Conselhos sobre divisões e problemas na igreja...', detailedImage: 'assets/detailed-1corinthians.jpg' },
        { title: '2 Coríntios', description: 'A defesa do ministério de Paulo...', image: 'assets/book-cover4.jpg', detailedDescription: 'Encorajamento e reconciliação...', detailedImage: 'assets/detailed-2corinthians.jpg' },
        { title: 'Gálatas', description: 'Liberdade em Cristo...', image: 'assets/book-cover5.jpg', detailedDescription: 'A importância da fé acima da lei...', detailedImage: 'assets/detailed-galatians.jpg' },
        { title: 'Efésios', description: 'A unidade do corpo de Cristo...', image: 'assets/book-cover.jpg', detailedDescription: 'Paulo fala da vida em Cristo e na igreja...', detailedImage: 'assets/detailed-ephesians.jpg' },
        { title: 'Filipenses', description: 'Alegria e humildade em Cristo...', image: 'assets/book-cover1.jpg', detailedDescription: 'Paulo fala da alegria na perseguição...', detailedImage: 'assets/detailed-philippians.jpg' },
        { title: 'Colossenses', description: 'A supremacia de Cristo...', image: 'assets/book-cover2.jpg', detailedDescription: 'Cristo é o cabeça da igreja...', detailedImage: 'assets/detailed-colossians.jpg' },
        { title: '1 Tessalonicenses', description: 'Instruções para uma vida santa...', image: 'assets/book-cover3.jpg', detailedDescription: 'Encorajamento para os novos crentes...', detailedImage: 'assets/detailed-1thessalonians.jpg' },
        { title: '2 Tessalonicenses', description: 'A volta de Cristo...', image: 'assets/book-cover4.jpg', detailedDescription: 'Correção de mal-entendidos sobre o retorno de Jesus...', detailedImage: 'assets/detailed-2thessalonians.jpg' },
        { title: '1 Timóteo', description: 'Conselhos pastorais para Timóteo...', image: 'assets/book-cover5.jpg', detailedDescription: 'Orientações para a liderança da igreja...', detailedImage: 'assets/detailed-1timothy.jpg' },
        { title: '2 Timóteo', description: 'Últimas instruções de Paulo...', image: 'assets/book-cover.jpg', detailedDescription: 'Exortação para permanecer fiel...', detailedImage: 'assets/detailed-2timothy.jpg' },
        { title: 'Tito', description: 'Conselhos para organização da igreja...', image: 'assets/book-cover1.jpg', detailedDescription: 'Orientações sobre a vida cristã...', detailedImage: 'assets/detailed-titus.jpg' },
        { title: 'Filemom', description: 'Pedido pessoal de Paulo...', image: 'assets/book-cover2.jpg', detailedDescription: 'Carta sobre perdão e reconciliação...', detailedImage: 'assets/detailed-philemon.jpg' },
      ]
    },
    {
      name: 'Cartas Gerais',
      books: [
        { title: 'Hebreus', description: 'A superioridade de Cristo...', image: 'assets/book-cover3.jpg', detailedDescription: 'Cristo é o sumo sacerdote perfeito...', detailedImage: 'assets/detailed-hebrews.jpg' },
        { title: 'Tiago', description: 'A fé em ação...', image: 'assets/book-cover4.jpg', detailedDescription: 'Instruções práticas sobre a vida cristã...', detailedImage: 'assets/detailed-james.jpg' },
        { title: '1 Pedro', description: 'Esperança e perseverança no sofrimento...', image: 'assets/book-cover5.jpg', detailedDescription: 'Encorajamento para crentes perseguidos...', detailedImage: 'assets/detailed-1peter.jpg' },
        { title: '2 Pedro', description: 'Aviso contra falsos mestres...', image: 'assets/book-cover.jpg', detailedDescription: 'Instruções sobre crescimento espiritual...', detailedImage: 'assets/detailed-2peter.jpg' },
        { title: '1 João', description: 'O amor de Deus manifestado...', image: 'assets/book-cover1.jpg', detailedDescription: 'Ensinamentos sobre amor e verdade...', detailedImage: 'assets/detailed-1john.jpg' },
        { title: '2 João', description: 'Advertência contra falsos ensinadores...', image: 'assets/book-cover2.jpg', detailedDescription: 'Paulo ensina sobre o amor e obediência...', detailedImage: 'assets/detailed-2john.jpg' },
        { title: '3 João', description: 'Conselhos sobre hospitalidade...', image: 'assets/book-cover3.jpg', detailedDescription: 'A importância de receber crentes fiéis...', detailedImage: 'assets/detailed-3john.jpg' },
        { title: 'Judas', description: 'Advertência contra apostasia...', image: 'assets/book-cover4.jpg', detailedDescription: 'A luta contra falsos mestres e apostasia...', detailedImage: 'assets/detailed-jude.jpg' },
      ]
    },
    {
      name: 'Apocalíptico',
      books: [
        { title: 'Apocalipse', description: 'Revelações sobre o fim dos tempos...', image: 'assets/book-cover5.jpg', detailedDescription: `Visões do futuro e o retorno de Cristo, com uma mensagem de esperança para os cristãos. O livro de Apocalipse, também conhecido como Revelação, é o último livro da Bíblia e contém uma visão profética dada ao apóstolo João enquanto ele estava exilado na ilha de Patmos. Ele é, sem dúvida, um dos livros mais simbólicos e enigmáticos da Escritura, revelando não apenas o futuro, mas também o propósito eterno de Deus para a humanidade e a criação.
          Apocalipse é uma mensagem de esperança para os cristãos, especialmente aqueles que sofrem perseguição. Apesar das circunstâncias difíceis que o povo de Deus pode enfrentar, o livro garante que o mal será derrotado e que Jesus Cristo retornará triunfante. No final, Deus renovará todas as coisas e reinará em glória para sempre.
          Em Apocalipse 1:17-18, Cristo ressurreto aparece em glória, lembrando-nos de que Ele é o primeiro e o último, aquele que vive para sempre e tem as chaves da morte e do inferno. Suas palavras "Não temas" nos convidam a confiar no Seu poder absoluto sobre todas as circunstâncias. Quando João vê Jesus em Sua forma glorificada, sua reação é a de cair como morto. Isso nos ensina a reverência e o temor que devemos ter diante do poder de Deus. O Cristo ressurreto não é apenas o Cordeiro que foi sacrificado, mas o Leão da tribo de Judá, glorificado e exaltado.
          O consolo está nas palavras de Jesus: "Não temas." Quantas vezes nos encontramos temerosos diante das circunstâncias da vida, diante da dor, da perseguição, ou do desconhecido? Jesus nos relembra: Ele é o "Primeiro e o Último", Aquele que esteve morto e agora vive para sempre! O domínio de Cristo sobre a vida e a morte é absoluto, Ele tem as chaves da morte e do inferno.       
          Essa é a nossa segurança como cristãos. Se Jesus venceu a morte, o que temos a temer? Não importa o que aconteça ao nosso redor, nossa esperança está n'Aquele que já conquistou o inimigo final, e Ele nos convida a confiar n'Ele em todas as circunstâncias.
          Aplicação: O que está te assustando hoje? Talvez sejam problemas familiares, dificuldades financeiras, ou o medo do futuro. Lembre-se das palavras de Cristo: "Não temas". Ele não só entende nossa dor, mas tem o controle absoluto sobre tudo. Ele tem as chaves! Confie n'Aquele que venceu a morte e vive eternamente.`
          , detailedImage: 'assets/detailed-revelation.png' },
      ]
    },
  ];

  constructor(private navCtrl: NavController) {}

  goToBookDetail(book: Book) {
    this.navCtrl.navigateForward('/coisa-livro', {
      queryParams: { book: JSON.stringify(book) },
    });
  }
}
