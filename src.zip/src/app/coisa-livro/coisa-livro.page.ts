import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-coisa-livro',
  templateUrl: './coisa-livro.page.html',
  styleUrls: ['./coisa-livro.page.scss'],
})
export class CoisaLivroPage {
  book: any; // Variável para armazenar o livro detalhado

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    // Obtém os parâmetros da URL e converte o livro de volta para um objeto
    this.route.queryParams.subscribe(params => {
      this.book = JSON.parse(params['book']);
    });
  }
}
