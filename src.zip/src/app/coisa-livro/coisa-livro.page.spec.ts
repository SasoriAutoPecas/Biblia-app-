import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoisaLivroPage } from './coisa-livro.page';

describe('CoisaLivroPage', () => {
  let component: CoisaLivroPage;
  let fixture: ComponentFixture<CoisaLivroPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CoisaLivroPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
